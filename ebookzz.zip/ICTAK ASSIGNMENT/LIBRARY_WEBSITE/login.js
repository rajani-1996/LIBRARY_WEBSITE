
function validate(){
    let email = document.getElementById("email").value;
    let label = document.getElementById("check");
    let regexp = /^([a-zA-Z0-9\.-]+)@([a-zA-Z0-9-]+).([a-z]{2,5})(.[a-z]{2,4})?$/;
if (regexp.test(email)){
    label.innerHTML = "Valid";
    label.style.color = "Green";
    label.style.visibility = "visible";
    return true;

}
else{
    label.innerHTML = "Invalid";
    label.style.color = "red";
    label.style.visibility = "visible";
    return false;

}
}



function validatePassword(){
    let pwd = document.getElementById("pwd").value;
    let label = document.getElementById("find");
    let regexp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
if (regexp.passwrd(pwd)){
    label.innerHTML = "Valid";
    label.style.color = "Green";
    label.style.visibility = "visible";
    return true;

}
else{
    label.innerHTML = "Invalid";
    label.style.color = "red";
    label.style.visibility = "visible";
    return false;


}
}





